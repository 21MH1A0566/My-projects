from tkinter import Tk
from sketch_image import SketchImage

def main():
    root = Tk()
    app = SketchImage(root)
    root.mainloop()

if __name__ == "__main__":
    main()
